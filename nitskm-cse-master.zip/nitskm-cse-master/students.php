<!DOCTYPE html>

<html lang="en">
  <head>
    <meta charset="utf-8">
    <link rel="icon" type="image/png" href="images/logo.png"/>
    <title>CSE | NIT Sikkim</title>
    <link rel="stylesheet" href="css/students.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="fonts/fonts.css">

    <?php
      $localFile = 3;
      $subFile = 4;
    ?>
  </head>

  <div class="preloader"></div>

  <?php include 'includes/header.php'; ?>

  <body>
    <div id="body-preloader-config">
      <div class="submenu-wrapper">
        <div class="tab-wrapper">
          <ul class="submenu-tabs">
            <li class="submenu-tab-link active" data-list="1">B. Tech</li>
            <li class="submenu-tab-link" data-list="2">M. Tech</li>
          </ul>
        </div>
      </div>

      <div class="submenu-content-wrapper">
        <div id="data-tab-1" class="submenu-tab-content active">
          <div>
            <button class="btn" id="b10" batch="b10" course="btech"><i class="btn-icon material-icons">check_circle</i><span>2010 <b>-</b> 2014</span></button>
            <button class="btn" id="b11" batch="b11" course="btech"><i class="btn-icon material-icons">check_circle</i><span>2011 <b>-</b> 2015</span></button>
            <button class="btn" id="b12" batch="b12" course="btech"><i class="btn-icon material-icons">check_circle</i><span>2012 <b>-</b> 2016</span></button>
            <button class="btn" id="b13" batch="b13" course="btech"><i class="btn-icon material-icons">check_circle</i><span>2013 <b>-</b> 2017</span></button>
            <button class="btn" id="b14" batch="b14" course="btech"><i class="btn-icon material-icons">check_circle</i><span>2014 <b>-</b> 2018</span></button>
            <button class="btn" id="b15" batch="b15" course="btech"><i class="btn-icon material-icons">check_circle</i><span>2015 <b>-</b> 2019</span></button>
            <button class="btn" id="b16" batch="b16" course="btech"><i class="btn-icon material-icons">check_circle</i><span>2016 <b>-</b> 2020</span></button>
            <button class="btn" id="b17" batch="b17" course="btech"><i class="btn-icon material-icons">check_circle</i><span>2017 <b>-</b> 2021</span></button>
            <button class="btn" id="b18" batch="b18" course="btech"><i class="btn-icon material-icons">check_circle</i><span>2018 <b>-</b> 2022</span></button>
          </div>

          <div id="b-loading-anim">
            <img src="images/loading.gif" style="height: 100px; width: 100px">
          </div>

          <div id="b-students-list" class="table-students">
            <h2 id="b-batch-name"></h2>
            <h3 id="b-fetch-error"></h3>
            <table style="margin: 0px auto;" id="b-table">            
        
            </table>
          </div>
        </div>
        <div id="data-tab-2" class="submenu-tab-content">
          <div>
            <button class="btn" id="m15" batch="m15" course="mtech"><i class="btn-icon material-icons">check_circle</i><span>2015 <b>-</b> 2017</span></button>
            <button class="btn" id="m16" batch="m16" course="mtech"><i class="btn-icon material-icons">check_circle</i><span>2016 <b>-</b> 2018</span></button>
            <button class="btn" id="m17" batch="m17" course="mtech"><i class="btn-icon material-icons">check_circle</i><span>2017 <b>-</b> 2019</span></button>
            <button class="btn" id="m18" batch="m18" course="mtech"><i class="btn-icon material-icons">check_circle</i><span>2018 <b>-</b> 2020</span></button>
          </div>

          <div id="m-loading-anim">
            <img src="images/loading.gif" style="height: 100px; width: 100px">
          </div>

          <div id="m-students-list" class="table-students">
            <h2 id="m-batch-name"></h2>
            <h3 id="m-fetch-error"></h3>
            <table style="margin: 0px auto;" id="m-table">
              
            </table>
          </div>
        </div>
      </div>
    </div>
  </body>

  <?php include 'footer.html'; ?>

  <script src="js/jquery-3.4.2-min.js"></script>
  <script src="js/main.js"></script>
  <script src="js/students.js"></script>
</html>