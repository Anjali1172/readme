<?php
    if(!empty($localFile))
      $pageCode = $localFile;
    else
			$pageCode = 0;

		$classOfOption = array();
		$dropdownLinkStatus = array(
			array('href="index.php"'),
			array('href="labs.php"'),
			array('href="faculty.php"', 'href="researchers.php"', 'href="staff.php"', 'href="students.php"'),
			array('href="bTimetable.php"', 'href="mTimetable.php"'),
			array('href="bSyllabus.php"', 'href="mSyllabus.php"')
		);

		for($i = 0; $i < 6; $i++){
			array_push($classOfOption, 'tab-link');
			if($pageCode - 1 == $i)
				$classOfOption[$i] = 'tab-link active';
		}

		$dropdownLinkStatus[$pageCode - 1][$subFile - 1] = 'class="dropdown-link-active"';
		if($pageCode == 1)
			$dropdownLinkStatus[0][0] = 'href="#"';
?>

<div class="wrapper">
	<div id="desktop-menu" class="tab-wrapper">
		<ul class="tabs">
			<a <?php echo $dropdownLinkStatus[0][0]; ?>><li id="menu-option-1" class="<?php echo $classOfOption[0]; ?>"><i class="desktop-menu-icon material-icons">home</i>About</li></a>
			<div class="dropdown">
				<li id="menu-option-2" class="<?php echo $classOfOption[1]; ?>" dropdown="1"><i class="desktop-menu-icon material-icons">domain</i>Facilities<i class="desktop-menu-dropdown material-icons" arrow-toggle="1">keyboard_arrow_down</i></li>
				<div class="dropdown-content" id="dropdown-1">
					<a <?php echo $dropdownLinkStatus[1][0]; ?>>Labs</a>
				</div>
			</div>
			<div class="dropdown">
				<li id="menu-option-3" class="<?php echo $classOfOption[2]; ?>" dropdown="2"><i class="desktop-menu-icon material-icons">people</i>People<i class="desktop-menu-dropdown material-icons" arrow-toggle="2">keyboard_arrow_down</i></li>
				<div class="dropdown-content" id="dropdown-2">
					<a <?php echo $dropdownLinkStatus[2][0]; ?>>Faculty</a>
					<a <?php echo $dropdownLinkStatus[2][1]; ?>>Researchers</a>
					<a <?php echo $dropdownLinkStatus[2][2]; ?>>Staff</a>
					<a <?php echo $dropdownLinkStatus[2][3]; ?>>Students</a>
				</div>
			</div>
			<div class="dropdown">
				<li id="menu-option-4" class="<?php echo $classOfOption[3]; ?>" dropdown="3"><i class="desktop-menu-icon material-icons">today</i>Timetable<i class="desktop-menu-dropdown material-icons" arrow-toggle="3">keyboard_arrow_down</i></li>
				<div class="dropdown-content" id="dropdown-3">
					<a <?php echo $dropdownLinkStatus[3][0]; ?>>B. Tech</a>
					<a <?php echo $dropdownLinkStatus[3][1]; ?>>M. Tech</a>
				</div>
			</div>
			<div class="dropdown">
				<li id="menu-option-5" class="<?php echo $classOfOption[4]; ?>" dropdown="4"><i class="desktop-menu-icon material-icons">assessment</i>Syllabus<i class="desktop-menu-dropdown material-icons" arrow-toggle="4">keyboard_arrow_down</i></li>
				<div class="dropdown-content" id="dropdown-4">
					<a <?php echo $dropdownLinkStatus[4][0]; ?>>B. Tech</a>
					<a <?php echo $dropdownLinkStatus[4][1]; ?>>M. Tech</a>
				</div>
			</div>
			<li id="menu-option-6" class="tab-link"><i class="desktop-menu-icon material-icons">school</i>Placements</li>
		</ul>
	</div>
</div>