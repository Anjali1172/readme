<!DOCTYPE html>

<html lang="en">
  <head>
    <meta charset="utf-8">
    <link rel="icon" type="image/png" href="images/logo.png"/>
    <title>CSE | NIT Sikkim</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="fonts/fonts.css">
    <link rel="stylesheet" href="css/index.css">

    <?php
      $localFile = 1;
      $subFile = 0;
    ?>
  </head>

  <div class="preloader"></div>

  <?php include 'includes/header.php'; ?>

  <body>
    <div id="body-preloader-config">
      <?php include 'includes/announcement.html'; ?>
      <br>
      <div class="slideshow-container">
        <div class="mySlides fade">
          <img id="img1" src="images/1.jpg">
        </div>

        <div class="mySlides fade">
          <img id="img2" src="">
        </div>

        <div class="mySlides fade">
          <img id="img3" src="">
        </div>

        <div class="mySlides fade">
          <img id="img4" src="">
        </div>

        <div class="mySlides fade">
          <img id="img5" src="">
        </div>
      </div>
      <br>
      <div style="text-align:center">
        <span class="dot" onclick="currentSlide(1)"></span> 
        <span class="dot" onclick="currentSlide(2)"></span> 
        <span class="dot" onclick="currentSlide(3)"></span> 
        <span class="dot" onclick="currentSlide(4)"></span> 
        <span class="dot" onclick="currentSlide(5)"></span> 
      </div>

      <div class="content-wrapper">
        <div class="tab-content">
          <p>The Department of Computer Science and Engineering (CSE) is one of the departments that started operating from the initiation of National Institute of Technology Sikkim in the year 2010. The department aims to provide an outstanding research environment complemented by excellence in teaching.</p>
          <p>The CSE department offers four years B.Tech. degree, two years M.Tech. degree and PhD programmes. The department has a comprehensive curriculum on topics related to all aspects of Computer Science with an emphasis on applicability that is provided using latest techniques of engineering. The course structure is up-to-date and includes courses on state-of-the-art to equip the students and teachers with the latest developments in the field. It is also proposed to develop interdisciplinary and multidisciplinary projects based on the expertise of faculty members.</p>
          <p>The areas of research are Cryptography, Network Security, Parallel-Distributed and High-Performance Computing, Algorithms, Bioinformatics, Computer Animation, System Software, Software Engineering, Cloud Computing and Wireless and Sensor Networks to build research groups and leverage the research activities in Sikkim in particular, and North-East region in general using a coordinated effort of various other organization working in the field of community development using science and technology. The Department has state-of-the-art infrastructure supported by high speed Ethernet and wireless network.</p>
          <p>The department enjoys a rich research culture through various projects under schemes such as Visvessharya scheme, DIT and DST project grants, National Mission on Himalayan Studies, specific developmental projects for north-eastern region, etc. The department also contributes towards community developments through Unnat Bharat Plan and Scientific lifestyle development of local community (as per scheme of Department of Atomic Energy).</p>
          <p><b>Dr. Pratyay Kuila<br>Head of Computer Science & Engineering Department</b></p>
          <br>
        </div>
      </div>
    </div> 
  </body>

  <?php include 'footer.html'; ?>

  <script src="js/jquery-3.4.2-min.js"></script>
  <script src="js/main.js"></script>
  <script src="js/index.js"></script>
</html>