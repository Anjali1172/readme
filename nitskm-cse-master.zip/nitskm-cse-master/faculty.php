<!DOCTYPE html>

<html lang="en">
  <head>
    <meta charset="utf-8">
    <link rel="icon" type="image/png" href="images/logo.png"/>
    <title>CSE | NIT Sikkim</title>
    <link rel="stylesheet" href="css/people.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="fonts/fonts.css">

    <?php
      $localFile = 3;
      $subFile = 1;
    ?>
  </head>

  <div class="preloader"></div>

  <script>
      function goToProfile(profileId) {
        var url = "profile.php?profile=" + profileId;
        window.open(url, "_blank");
      }
  </script>

  <?php include 'includes/header.php'; ?>

  <body>
    <div id="body-preloader-config" class="content-wrapper">
      <div class="card-wrapper">
        <?php
          require_once('includes/db_connect.php');
          $query = "SELECT * FROM people_details WHERE department='Computer Science & Engineering' AND type = 'faculty' ORDER BY pref";
          $result = $connect->query($query);
       
          if($result->num_rows > 0){
            while($row = $result->fetch_assoc()){
              echo "<div class='people-card'>";
              echo "<div class='card-text'>";
              echo "<div>";
              echo "<img src='images/profile_images/".$row['email'].".".$row['imagename']."' class='people-img' alt='image'>";
              echo "</div>";
              echo "<div>";
              echo "<h4><b>".$row['name']."</b></h4>";
              echo "<h4><b>".$row['designation']."</b></h4>";
              echo "<h4>".$row['mobile']."</h4>";
              echo "</div>";
              echo "<div>";
              echo "<button class='btn-azure btn' onclick='javascript:goToProfile(".$row['sn'].")'><i class='material-icons'>add</i><span><b>More</b></span></button>";
              echo "</div>";
              echo "</div>";
              echo "</div>";
            }
          }
        ?>
      </div>
    </div>
  </body>

  <?php include 'footer.html'; ?>

  <script src="js/jquery-3.4.2-min.js"></script>
  <script src="js/main.js"></script>
</html>