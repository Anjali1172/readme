<?php
    if(isset($_POST['batch'])){
        if(!empty($_POST['batch'])){
            require_once('db_connect.php');
            $batch = mysqli_real_escape_string($connect, $_POST['batch']);
            $batches = array("b10", "b11", "b12", "b13", "b14", "b15", "b16", "b17", "b18", "m15", "m16", "m17", "m18");

            if(in_array($batch, $batches)){
                $count = 1;
                $query = "SELECT * FROM student_details WHERE batch = '$batch' AND branch = 'cs'";
                $result = $connect->query($query);
                if($result->num_rows > 0){
                    echo "<thead>";
                    echo "<tr>";
                    echo "<th>Sr. No.</th>";
                    echo "<th>Roll No.</th>";
                    echo "<th>Name</th>";
                    echo "<th>E-Mail</th>";
                    echo "</tr>";
                    echo "</thead>";
                    echo "<tbody>";
                    while($row = $result->fetch_assoc()){
                        echo "<tr>";
                        echo "<td>".$count."</td>";
                        echo "<td>".$row['roll']."</td>";
                        echo "<td>".$row['name']."</td>";
                        echo "<td>".$row['email']."</td>";
                        echo "</tr>";
                        $count++;
                    }
                    echo "</tbody>";
                }
                else{
                    echo "error_no_records";
                    exit();
                }
            }
            else{
                echo "error_invalid_batch";
                exit();
            }
        }
        else{
            echo "error_empty_request";
            exit();
        }
    }
    else{
        echo "error_processing_request";
        exit();
    }
?>