<!DOCTYPE html>

<html lang="en">
  <head>
    <meta charset="utf-8">
    <link rel="icon" type="image/png" href="images/logo.png"/>
    <title>CSE | NIT Sikkim</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="fonts/fonts.css">

    <?php
      $localFile = 5;
      $subFile = 1;
    ?>
  </head>

  <div class="preloader"></div>

  <?php include 'includes/header.php'; ?>

  <body>
    <div id="body-preloader-config" class="content-wrapper">
      <h2>B. Tech Syllabus</h2>
      <div>
        <button class="btn btn-green-hover"><i class="btn-icon material-icons" onclick="location.href='../syll&curr/Curriculum Effective from 2017 Admitted Batch Onwards.pdf'">get_app</i><span>CURRICULLUM</span></button>
        <button class="btn btn-green-hover"><i class="btn-icon material-icons" onclick="location.href='../syll&curr/Syllabus Effective from 2017 Admitted Batch Onwards (1).pdf'">get_app</i><span>SYLLABUS</span></button>
      </div>
    </div>
  </body>

  <?php include 'footer.html'; ?>
  <script src="js/jquery-3.4.2-min.js"></script>
  <script src="js/main.js"></script>
</html>