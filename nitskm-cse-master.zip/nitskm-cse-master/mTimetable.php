<!DOCTYPE html>

<html lang="en">
  <head>
    <meta charset="utf-8">
    <link rel="icon" type="image/png" href="images/logo.png"/>
    <title>CSE | NIT Sikkim</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="fonts/fonts.css">

    <?php
      $localFile = 4;
      $subFile = 2;
    ?>
  </head>

  <div class="preloader"></div>

  <?php include 'includes/header.php'; ?>

  <body>
    <div id="body-preloader-config" class="content-wrapper">
      <h2>M. Tech Timetable</h2>
      <div>
        <button class="btn btn-green-hover"><i class="btn-icon material-icons" onclick="location.href=''">get_app</i><span>1<sup>st</sup> SEMESTER</span></button>
      </div>
    </div>
  </body>

  
  <?php include 'footer.html'; ?>
  <script src="js/jquery-3.4.2-min.js"></script>
  <script src="js/main.js"></script>
</html>