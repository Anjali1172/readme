<?php
    if(isset($_POST['type'])){
        if(!empty($_POST['type'])){
            require_once('db_connect.php');
            $type = mysqli_real_escape_string($connect, $_POST['type']);
            if($type == "feedback"){
                // for feedback
                if(isset($_POST['feedback-text'])){
                    if(!empty($_POST['feedback-text'])){
                        $text = mysqli_real_escape_string($connect, $_POST['feedback-text']);
                        $query = "INSERT INTO feedback (type, info) VALUES ('$type', '$text')";
                        $result = $connect->query($query);

                        if(mysqli_affected_rows($connect) == 1){
                            echo "feedback_submitted";
                            exit();
                        }
                        else{
                            echo "error_unknown";
                            exit();
                        }
                    }
                    else{
                        echo "error_empty_fields";
                        exit();
                    }
                }
                else{
                    echo "error_empty_fields";
                    exit();
                }
            }
            else if($type == "survey"){
                // for survey

            }
            else{
                echo "error_invalid_request";
                exit();
            }
        }
        else{
            echo "error_incomplete_request";
            exit();
        }
    }
    else{
        echo "error_processing_request";
        exit();
    }
?>