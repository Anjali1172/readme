<header id="header-preloader-config">
    <div class="header">
      <div id="hamburger"><i class="mobile-menu-icon material-icons" onclick="javascript:showMobileMenu()">menu</i></div>
      <div id="logo" class="dept-logo" onclick="#"><img src="images/logo.svg" alt="NIT Sikkim Logo"></div>
      <div id="dept-hindi" class="dept-text">संगणक विज्ञान एवं अभियांत्रिकी विभाग</div>
      <div id="dept-english" class="dept-text">Computer Science & Engineering Department</div>
      <div id="institute-name" class="dept-text">National Institute of Technology Sikkim</div>
    </div>

    <?php include 'mobileMenu.php'; ?>
    <?php include 'desktopMenu.php'; ?>
</header>