// function to hide list after clicking back button
function listClose() {
	$("#b-students-list").css({'display': 'none'});
	$("#m-students-list").css({'display': 'none'});
	$(".btn").siblings().removeClass('btn-green');
	$(".btn").siblings().attr("disabled", false);
};

// function to reset page to default
function resetPageDefaults(batchList, batchName, fetchError, tableBody) {
	$(batchList).css({'display': 'none'});
	$(fetchError).html(" ");
	$(batchName).html(" ");
	$(tableBody).html(" ");
}

// function to change color of currently open tab of submenu
function buttonChange(id) {
	$("#" + id).addClass('btn-green').siblings().removeClass('btn-green');
	$("#" + id).attr("disabled", true).siblings().attr("disabled", false);
}

// function to fetch details of students (via ajax request)
$(".btn").click(function() {
	var batch = $(this).attr('batch');
	var id = $(this).attr('id');	// to disable button of currently open submenu
	var course = $(this).attr('course');
	var getDetailsUrl = 'includes/retrieveStudents.php';
	var batchInfo = {'batch': batch};
	var batchYear = "-";
	var animIcon = "";
	var batchName = "";
	var batchList = "";
	var tableBody = "";
	var fetchError = "";
	var listCloseBtn = "<a href='javascript:void(0)' onclick='javascript:listClose()'><i class='material-icons'>keyboard_arrow_left</i></a>";

	buttonChange(id);
	
	if(course == "btech"){
		animIcon = "#b-loading-anim";
		batchName = "#b-batch-name";
		batchList = "#b-students-list";
		tableBody = "#b-table";
		fetchError = "#b-fetch-error";
	}
	else{
		animIcon = "#m-loading-anim";
		batchName = "#m-batch-name";
		batchList = "#m-students-list";
		tableBody = "#m-table";
		fetchError = "#m-fetch-error";
	}

	resetPageDefaults(batchList, batchName, fetchError, tableBody);

	if(batch == "b10"){
		batchYear = "Batch 2010 - 2014";
	}
	else if(batch == "b11"){
		batchYear = "Batch 2011 - 2015";
	}
	else if(batch == "b12"){
		batchYear = "Batch 2012 - 2016";
	}
	else if(batch == "b13"){
		batchYear = "Batch 2013 - 2017";
	}
	else if(batch == "b14"){
		batchYear = "Batch 2014 - 2018";
	}
	else if(batch == "b15"){
		batchYear = "Batch 2015 - 2019";
	}
	else if(batch == "b16"){
		batchYear = "Batch 2016 - 2020";
	}
	else if(batch == "b17"){
		batchYear = "Batch 2017 - 2021";
	}
	else if(batch == "b18"){
		batchYear = "Batch 2018 - 2022";
	}
	else if(batch == "m15"){
		batchYear = "Batch 2015 - 2017";
	}
	else if(batch == "m16"){
		batchYear = "Batch 2016 - 2018";
	}
	else if(batch == "m17"){
		batchYear = "Batch 2017 - 2019";
	}
	else if(batch == "m18"){
		batchYear = "Batch 2018 - 2020";
	}
	else{
		batchYear = "-";
	}

	batchYear = listCloseBtn + batchYear;

	$.ajax({
		type: 'POST',
		data: batchInfo,
		url: getDetailsUrl,
		beforeSend: function(){
			$(animIcon).css({'display': 'block'});
		},
		success: function(recieve){
			$(batchName).html(batchYear);
			$(batchName).css({'display': 'block'});
			$(animIcon).css({'display': 'none'});
			$(batchList).css({'display': 'block'});
			if(recieve == "error_no_records"){
				$(fetchError).css({'display': 'block'});
				$(fetchError).html("ERROR: No records found !");
				return;
			}
			$(tableBody).html(recieve);
		}
	});
});