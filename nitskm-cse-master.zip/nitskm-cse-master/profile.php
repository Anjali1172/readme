<!DOCTYPE html>

<html lang="en">
  <head>
    <meta charset="utf-8">
    <link rel="icon" type="image/png" href="images/logo.png"/>
    <title>CSE | NIT Sikkim</title>
    <link rel="stylesheet" href="css/people.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="fonts/fonts.css">    
  </head>

  <div class="preloader"></div>

  <header id="header-preloader-config">
    <div class="header">
      <div class="dept-logo"><a href="#"><img src="images/logo.svg" alt="NIT Sikkim Logo"></a></div>
      <div class="dept-text">संगणक विज्ञान एवं अभियांत्रिकी विभाग</div>
      <div class="dept-text">Computer Science & Engineering Department</div>
    </div>

    <div class="wrapper">

      <?php include 'includes/mobileMenu.php'; ?>
      
      <div id="desktop-menu" class="tab-wrapper">
        <ul class="tabs">
          <a href="index.php"><li id="menu-option-1" class="tab-link"><i class="desktop-menu-icon material-icons">home</i>About</li></a>
          <div class="dropdown">
            <li id="menu-option-2" class="tab-link" dropdown="1"><i class="desktop-menu-icon material-icons">domain</i>Facilities<i class="desktop-menu-dropdown material-icons" arrow-toggle="1">keyboard_arrow_down</i></li>
            <div class="dropdown-content" id="dropdown-1">
              <a href="labs.php">Labs</a>
            </div>
          </div>
          <div class="dropdown">
            <li id="menu-option-3" class="tab-link active" dropdown="2"><i class="desktop-menu-icon material-icons">people</i>People<i class="desktop-menu-dropdown material-icons" arrow-toggle="2">keyboard_arrow_down</i></li>
            <div class="dropdown-content" id="dropdown-2">
              <a href="faculty.php">Faculty</a>
              <a href="researchers.php">Researchers</a>
              <a href="staff.php">Staff</a>
              <a href="students.php">Students</a>
            </div>
          </div>
          <div class="dropdown">
            <li id="menu-option-4" class="tab-link" dropdown="3"><i class="desktop-menu-icon material-icons">today</i>Timetable<i class="desktop-menu-dropdown material-icons" arrow-toggle="3">keyboard_arrow_down</i></li>
            <div class="dropdown-content" id="dropdown-3">
              <a href="bTimetable.php">B. Tech</a>
              <a href="mTimetable.php">M. Tech</a>
            </div>
          </div>
          <div class="dropdown">
            <li id="menu-option-5" class="tab-link" dropdown="4"><i class="desktop-menu-icon material-icons">assessment</i>Syllabus<i class="desktop-menu-dropdown material-icons" arrow-toggle="4">keyboard_arrow_down</i></li>
            <div class="dropdown-content" id="dropdown-4">
              <a href="bSyllabus.php">B. Tech</a>
              <a href="mSyllabus.php">M. Tech</a>
            </div>
          </div>
          <li id="menu-option-6" class="tab-link"><i class="desktop-menu-icon material-icons">school</i>Placements</li>
        </ul>
      </div>
    </div>
  </header>

  <body>
    <div id="body-preloader-config" class="content-wrapper">
      <?php
        require_once('includes/db_connect.php');
        $idcheck = 0;
        $profileid = "";
        if(isset($_GET['profile'])){
          if(!empty($_GET['profile'])){
            $profileid = mysqli_real_escape_string($connect, $_GET['profile']);
            $idcheck = 1;
          }
        }
        
        $query = "SELECT * FROM people_details WHERE department='Computer Science & Engineering' AND type = 'faculty' AND sn = '$profileid'";  // (type = 'faculty' OR type = 'staff')
        $result = $connect->query($query);

        if(($result->num_rows > 0) && $idcheck == 1){
          while($row = $result->fetch_assoc()){
            echo "<div class='profile-card'>";
            echo "<div class='center-image'>";
            echo "<img src='images/profile_images/".$row['email'].".".$row['imagename']."' class='profile-img' alt='image'>";
            echo "</div>";
            echo "<div class='card-text'>";
            echo "<div class='col-40-left'>";
            echo "<h4 class='profile-name'><b>Name: &nbsp;</b>".$row['name']."</h4>";
            echo "</div>";
            echo "<div class='people-profile-details'>";
            
            echo "</div>";
            echo "</div>";
            echo "</div>";
          }
        }
        else{
          ?>
            <script>
              alert("Error !");
            </script>
          <?php
        }
      ?>
    </div>
  </body>

  <?php include 'footer.html'; ?>
  <script src="js/jquery-3.4.2-min.js"></script>
  <script src="js/main.js"></script>
</html>