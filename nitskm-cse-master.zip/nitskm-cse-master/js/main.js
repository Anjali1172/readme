// setting 'visibility: visible' for header, body and footer after page has loaded
$(window).on('load', function() {
	$("#header-preloader-config, #body-preloader-config, #footer-preloader-config").css({'visibility': 'visible'});
	var loader = document.getElementsByClassName('preloader');
    loader[0].style.display = "none";
});

// function to control desktop dropdown menus
$('.tab-link').click(function() {
	var dropID = $(this).attr('dropdown');
	var i = 1;
	for(i = 1; i <= 4; i++){
		if(i != dropID)
			$("#dropdown-" + i).removeClass("display-block");
	}

	if(dropID){
		$("#dropdown-" + dropID).toggleClass("display-block");
		
	}
});

// --
$(".tab-link").click(function(e) {
	e.stopPropagation();
});

// function to close every dropdown menu if clicked anywhere outside
$(document).click(function() {
	var i;
	for(i = 1; i <= 4; i++){
		$("#dropdown-" + i).removeClass("display-block");
	}
});

// function for submenus (students.php)
$('.submenu-tab-link').click(function() {
	var tabID = $(this).attr('data-list');
	$(this).addClass('active').siblings().removeClass('active');
	$('#data-tab-' + tabID).addClass('active').siblings().removeClass('active');
});

// function to show mobile menu
function showMobileMenu() {
	var mobileMenu = ".mobile-menu-icon";
	if($(mobileMenu).attr('onclick') == "javascript:showMobileMenu()"){
		$(mobileMenu).attr('onclick', "javascript:closeMobileMenu()");
		$(mobileMenu).html("close");
		$(".mobile-menu-sidebar").css({'display': 'block'});
		$(".mobile-menu-sidebar").removeClass('fade-out-left').addClass('fade-in-left');
	}
}

// function to hide mobile menu
function closeMobileMenu() {
	var mobileMenu = ".mobile-menu-icon";
	if($(mobileMenu).attr('onclick') == "javascript:closeMobileMenu()"){
		$(mobileMenu).attr('onclick', "javascript:showMobileMenu()");
		$(mobileMenu).html("menu");
		$(".mobile-menu-sidebar").removeClass('fade-in-left').addClass('fade-out-left');
	}
}

$(".mobile-menu-sidebar, .mobile-menu-icon").click(function(e) {
	e.stopPropagation();
});

// function to close every dropdown menu if clicked anywhere outside
$(document).click(function() {
	closeMobileMenu();
});

/*
$('.mobile-menu-link').click(function() {
	var dropID = $(this).attr('dropdown');
	var i = 1;
	for(i = 1; i <= 4; i++){
		if(i != dropID)
			$("#mobile-dropdown-" + i).removeClass("display-block");
	}

	if(dropID){
		$("#mobile-dropdown-" + dropID).toggleClass("display-block");
		
	}
});

$(".mobile-menu-link").click(function(e) {
	e.stopPropagation();
});
*/

// submit feedback without reloading (using an ajax request)
$("#feedback-form").on('submit', function(e) {
	e.preventDefault();

	var errorEmpty = "Please fill the fields properly !";
	if($("#feedback-text").val().length === 0){
		alert(errorEmpty);
		return;
	}

	var formData = $("#feedback-form").serializeArray();
	formData.push({ name: "type", value: "feedback"});
	$.ajax({
		type: 'POST',
		url: 'includes/feedbackSubmit.php',
		data: formData,
		beforeSend: function() {
			//$("#feedback-submit-btn").attr('disabled', 'true');
			$("#feedback-submit-btn").css({'background-color': 'orange'});
			$("#feedback-submit-btn").css({'width': 'fit-content'});
			$("#feedback-submit-btn").html("Submitting ...");
		},
		success: function(responseData) {
			//$("#feedback-submit-btn").attr('disabled', 'false');
			$("#feedback-submit-btn").css({'background-color': '#4CAF50'});
			$("#feedback-submit-btn").css({'width': '110px'});
			$("#feedback-submit-btn").html("<span>Submit</span>");
			if(responseData == "feedback_submitted"){
				alert("Feedback was successfully submitted !");
				$("#feedback-text").val("");
			}
			else if(responseData == "error_empty_fields"){
				alert(errorEmpty);
			}
			else{
				alert("An error occurred !");
			}
		}
	});
});