// Set the width of the sidebar to 250px and the left margin of the page content to 250px
function openNav() {
	var check1 = $(".mobile-menu").css('display');
	var mySidebarStyleWidth = "400px";
	closeMobileMenu();
	
	if(check1 == "block"){
		mySidebarStyleWidth = "100%";
		mainBtnProperty = "none";
		document.getElementById("mainBtn").style.display = "none";
	}

	if (document.getElementById("mySidebar").style.width != mySidebarStyleWidth) {
		document.getElementById("mySidebar").style.width = mySidebarStyleWidth;
		document.getElementById("mainBtn").style.right = "330px";
	} else {
		closeNav();
	}
}

// Set the width of the sidebar to 0 and the left margin of the page content to 0 
function closeNav() {
	var check1 = $(".mobile-menu").css('display');
	var mainBtnStyleRight = "-70px";

	if(check1 == "block"){
		mainBtnStyleRight = "-100px";
	}

	document.getElementById("mainBtn").style.display = "block";
	document.getElementById("mySidebar").style.width = "0";
	document.getElementById("mainBtn").style.right = mainBtnStyleRight;
}

//stops closenav from operating when we click on the opened nav
$(".announcements").click(function(a) {
	a.stopPropagation();
});

//closes the announcements when we click anywhere other than the announcements
$(document).click(function() {
	closeNav();
});


// code for slideshow
$(document).ready(function() {
	currentSlide(1);
	setInterval(function() {
		plusSlides(1);
	}, 10000);
});
  
var slideIndex = 1;
showSlides(slideIndex);
  
function plusSlides(n) {
	showSlides(slideIndex += n);
}

function currentSlide(n) {
	showSlides(slideIndex = n);
}
  
function showSlides(n) {
	var i;
	var slides = document.getElementsByClassName("mySlides");
	var dots = document.getElementsByClassName("dot");
	if (n > slides.length)
	  slideIndex = 1;
	if (n < 1)
	  slideIndex = slides.length;
	for (i = 0; i < slides.length; i++) {
		slides[i].style.display = "none";  
	}
	for (i = 0; i < dots.length; i++) {
		dots[i].className = dots[i].className.replace(" active-img-btn", "");
	}
	
	slides[slideIndex-1].style.display = "block";  
	dots[slideIndex-1].className += " active-img-btn";
	slideIndex2 = slideIndex;
	var img = document.getElementById("img" + slideIndex2.toString());  
	img.src = "images/" + slideIndex2.toString() + ".jpg";
}