<!DOCTYPE html>

<html lang="en">
  <head>
    <meta charset="utf-8">
    <link rel="icon" type="image/png" href="images/logo.png"/>
    <title>CSE | NIT Sikkim</title>
    <link rel="stylesheet" href="css/people.css">
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="fonts/fonts.css">

    <?php
      $localFile = 3;
      $subFile = 2;
    ?>
  </head>

  <div class="preloader"></div>

  <?php include 'includes/header.php'; ?>

  <body>
    <div id="body-preloader-config" class="content-wrapper">
      <h2>Institute Research Scholars (Full Time)</h2>
      <div class="card-wrapper">
        <?php
          // Storing all values in array to minimize code
          // ft -> full time
          $names_ft = array("Mr. Sayantan Chatterjee", "Mr. Hanuman Godara", "Mr. Vivek Kumar", "Mr. Subhash Harizan", "Mr. Pintu Kumar Ram", "Mrs. Dipanwita Sadhukhan");
          $contact_ft = array("sayanc2011@gmail.com", "hanuman_godara@live.in", "phcs16026@nitsikkim.ac.in<br>9472084274", "phcs16019@nitsikkim.ac.in<br>7431899773", "phcs17002@nitsikkim.ac.in<br>+91 7363033431", "phcs17005@nitsikkim.ac.in");
          $aor_ft = array("Network Security and Cryptography", "HPC (High Performance Computing)", "Design of efficient and secure authentication schemes using identity-based cryptography (IBC)", "Wireless Sensor Networks", "Machine Learning", "Cryptography and Network Security");
          $ru_ft = array("Dr. S. G. Samaddar", "Prof. M. C. Govil", "Dr. Sangram Ray", "Dr. Pratyay Kuila", "Dr. Pratyay Kuila", "Dr. Sangram Ray");
          $img_ft = array("sayanc2011@gmail.com", "hanuman_godara@live.in", "phcs16026@nitsikkim.ac.in", "phcs16019@nitsikkim.ac.in", "phcs17002@nitsikkim.ac.in", "phcs17005@nitsikkim.ac.in");
          $i = 0;

          while($i < count($names_ft)){
            $img_ft[$i] = $img_ft[$i].".jpg";
            echo "<div class='people-card'>";
            echo "<div class='card-text'>";
            echo "<div>";
            echo "<img src='images/profile_images/".$img_ft[$i]."' class='people-img' alt='image'>";
            echo "</div>";
            echo "<div>";
            echo "<h4><b>".$names_ft[$i]."</b></h4>";
            echo "<h4>".$contact_ft[$i]."</h4>";
            echo "</div>";
            echo "<div>";
            echo "<h4><b>Area(s) of Research: </b>".$aor_ft[$i]."</h4>";
            echo "<h4><b>Research Under: </b>".$ru_ft[$i]."</h4>";
            echo "</div>";
            echo "</div>";
            echo "</div>";
            $i++;
          }
        ?>
      </div>

      <h2>Institute Research Scholars (Under Various Projects/Schemes)</h2>
      <div class="card-wrapper">
        <?php
          // uvp -> under various projects
          $names_uvp = array("Mr. Rahul Deo Verma", "Ms. Sharmistha Adhikari", "Mr. Deo Dutta Ishwar");
          $contact_uvp = array("19rahultitiaan@gmail.com<br>9713652598", "sharmistha.adhikari@gmail.com", "devnitb@gmail.com<br>9958573530");
          $aor_uvp = array("Design of Secured Border Gateway Routing Protocol", "Content Centric Network (CCN): its security aspects and design of some security solutions using Elliptic Curve Cryptography (ECC)", "Multimedia teaching and learning content optimisation");
          $ru_uvp = array("Dr. S G Samaddar", "Dr. Sangram Ray", "Prof. Arun B Samaddar");
          $img_uvp = array("19rahultitiaan@gmail.com", "sharmistha.adhikari@gmail.com", "devnitb@gmail.com");
          $i = 0;

          while($i < count($names_uvp)){
            $img_uvp[$i] = $img_uvp[$i].".jpg";
            echo "<div class='people-card'>";
            echo "<div class='card-text'>";
            echo "<div>";
            echo "<img src='images/profile_images/".$img_uvp[$i]."' class='people-img' alt='image'>";
            echo "</div>";
            echo "<div>";
            echo "<h4><b>".$names_uvp[$i]."</b></h4>";
            echo "<h4>".$contact_uvp[$i]."</h4>";
            echo "</div>";
            echo "<div>";
            echo "<h4><b>Area(s) of Research: </b>".$aor_uvp[$i]."</h4>";
            echo "<h4><b>Research Under: </b>".$ru_uvp[$i]."</h4>";
            echo "</div>";
            echo "</div>";
            echo "</div>";
            $i++;
          }
        ?>
      </div>

      <h2>Institute Research Scholars (Part Time)</h2>
      <div class="card-wrapper">
        <?php
          // pt -> part time
          $names_pt = array("Mr. Md Sarfaraj Alam Ansari", "Mr. Pankaj Kumar Keserwani", "Ms. Gopa Bhaumik", "Mr. Tarun Biswas", "Mr. B Balaji Naik", "Mr. Uddalak Chatterjee", "Mr. Ashis Datta", "Mr. Santanu Kumar Misra", "Mr. Suman Majumder", "Mr. Ujjal Kumar Das", "Mr. Himangshu Sarma");
          $contact_pt = array("mdsarfarajalam@gmail.com", "Pankajkeserwani.cse@nitsikkim.ac.in", "gopa.bhaumik09@gmail.com", "taru.widu@gmail.com", "balajinaik07@gmail.com<br>balajinaik07@yahoo.com", "uddalak.udi@gmail.com<br>8981057802", "ashis.smit@gmail.com<br>9614066962", "misra_santanu@rediffmail.com<br>8927257899", "suman.majumder3014@gmail.com<br>7059517951", "ujjalmnnit@gmail.com<br>9475210040", "himangshu.tezu@gmail.com");
          $aor_pt = array("Information Security", "Digital Forensic", "Image Processing", "Distributed Computing, MANET", "Cloud Computing", "Elliptic curve cryptography (ECC) based key management of Internet of things (IOT)", "Biometric Key generation and its application", "Energy efficient algorithms of HPC and cloud Data Center", "Internet of Things, its security aspects & some proposed security solutions", "Cryptography and Network Security", "Human Computer Interaction Natural Language Processing");
          $ru_pt = array("Dr. S.G. Samaddar<br>Prof. M C Govil", "Dr. S.G. Samaddar", "Dr. S. G. Samaddar<br>Prof. Arun B Samaddar", "Dr. Pratyay Kuila<br>Dr. Anjan Kumar Ray", "Prof. Arun B Samaddar<br>Dr. Dhanajay Singh", "Dr. Sangram Ray", "Dr. Sangram Ray", "Dr. Pratyay Kuila", "Dr. Sangram Ray", "Dr. S. G. Samaddar", "Prof. Arun B Samaddar<br>Prof. Rainer Malaka");
          $img_pt = array("mdsarfarajalam@gmail.com", "Pankajkeserwani.cse@nitsikkim.ac.in", "gopa.bhaumik09@nitsikkim.ac.in", "taru.widu@gmail.com", "balajinaik07@nitsikkim.ac.in", "uddalak@nitsikkim.ac.in", "ashis.smit@gmail.com", "misra_santanu@rediffmail.com", "suman.majumder3014@gmail.com", "ujjalmnnit@gmail.com", "himangshu.tezu@gmail.com");  // images of some people were already present.. so adjusted accordingly
          $i = 0;

          while($i < count($names_pt)){
            $img_pt[$i] = $img_pt[$i].".jpg";
            echo "<div class='people-card'>";
            echo "<div class='card-text'>";
            echo "<div>";
            echo "<img src='images/profile_images/".$img_pt[$i]."' class='people-img' alt='image'>";
            echo "</div>";
            echo "<div>";
            echo "<h4><b>".$names_pt[$i]."</b></h4>";
            echo "<h4>".$contact_pt[$i]."</h4>";
            echo "</div>";
            echo "<div>";
            echo "<h4><b>Area(s) of Research: </b>".$aor_pt[$i]."</h4>";
            echo "<h4><b>Research Under: </b>".$ru_pt[$i]."</h4>";
            echo "</div>";
            echo "</div>";
            echo "</div>";
            $i++;
          }
        ?>
      </div>
    </div>
  </body>

  <?php include 'footer.html'; ?>
  <script src="js/jquery-3.4.2-min.js"></script>
  <script src="js/main.js"></script>
</html>