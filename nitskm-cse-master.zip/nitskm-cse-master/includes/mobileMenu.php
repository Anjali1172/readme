<div id="mobile-menu" class="mobile-menu">
  <div class="mobile-menu-sidebar">
    <div class="mobile-menu-content">
      <h2>MENU</h2>
      <div>
        <div class="mobile-menu-link"><a href="index.php"><i class="mobile-menu-list-icon material-icons">home</i>About</a></div>
        <div class="mobile-menu-link"><a href="javascript:void(0)" onclick=""><i class="mobile-menu-list-icon material-icons">domain</i>Facilities<i class="mobile-menu-dropdown-icon material-icons">keyboard_arrow_down</i></a></div>
        <div class="mobile-submenu" id="">
          <p onclick="location.href='labs.php'">Labs</p>
        </div>
        <div class="mobile-menu-link"><a href="javascript:void(0)" onclick=""><i class="mobile-menu-list-icon material-icons">people</i>People<i class="mobile-menu-dropdown-icon material-icons">keyboard_arrow_down</i></a></div>
        <div class="mobile-submenu" id="">
          <p onclick="location.href='faculty.php'">Faculty</p>
          <p onclick="location.href='researchers.php'">Researchers</p>
          <p onclick="location.href='staff.php'">Staff</p>
          <p onclick="location.href='students.php'">Students</p>
        </div>
        <div class="mobile-menu-link"><a href="javascript:void(0)" onclick=""><i class="mobile-menu-list-icon material-icons">today</i>Timetable<i class="mobile-menu-dropdown-icon material-icons">keyboard_arrow_down</i></a></div>
        <div class="mobile-submenu" id="">
          <p onclick="location.href='bTimetable.php'">B. Tech</p>
          <p onclick="location.href='mTimetable.php'">M. Tech</p>
        </div>
        <div class="mobile-menu-link"><a href="javascript:void(0)" onclick=""><i class="mobile-menu-list-icon material-icons">assessment</i>Syllabus<i class="mobile-menu-dropdown-icon material-icons">keyboard_arrow_down</i></a></div>
        <div class="mobile-submenu" id="">
          <p onclick="location.href='bSyllabus.php'">B. Tech</p>
          <p onclick="location.href='mSyllabus.php'">M. Tech</p>
        </div>
        <div class="mobile-menu-link"><a href="#"><i class="mobile-menu-list-icon material-icons">school</i>Placements</a></div>
      </div>
    </div>
  </div>
</div>