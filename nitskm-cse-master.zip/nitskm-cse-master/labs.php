<!DOCTYPE html>

<html lang="en">
  <head>
    <meta charset="utf-8">
    <link rel="icon" type="image/png" href="images/logo.png"/>
    <title>CSE | NIT Sikkim</title>
    <link rel="stylesheet" href="css/style.css">
    <link rel="stylesheet" href="css/footer.css">
    <link rel="stylesheet" href="fonts/fonts.css">

    <?php
      $localFile = 2;
      $subFile = 1;
    ?>
  </head>

  <div class="preloader"></div>

  <?php include 'includes/header.php'; ?>

  <body>
    <div id="body-preloader-config">
    </div>
  </body>
  
  <?php include 'footer.html'; ?>
  <script src="js/jquery-3.4.2-min.js"></script>
  <script src="js/main.js"></script>
</html>